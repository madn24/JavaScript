// Select color input
// Select size input
var color = document.getElementById('colorPicker');
var size = document.getElementById('sizePicker');

// When size is submitted by the user, call makeGrid()

size.addEventListener('submit', function(event) {
    event.preventDefault();
    
    var height = document.getElementById('inputHeight').value;
    var width = document.getElementById('inputWidth').value;
    
    makeGrid(height, width);
});

function makeGrid(height, width) {

// Your code goes here!
    while (pixelCanvas.firstChild){
        pixelCanvas.removeChild(pixelCanvas.firstChild);
    }

    for (var i=1; i<=height; i++){
        var gridHeight = document.createElement('tr');
        pixelCanvas.appendChild(gridHeight);
        for (var j=1; j<=width; j++){
            var gridwidth = document.createElement('td');
            gridHeight.appendChild(gridwidth);
            gridwidth.addEventListener('click', function(){
                var coloring = document.getElementById('colorPicker').value;
                this.style.backgroundColor = coloring;
            })
        }
    }
}
